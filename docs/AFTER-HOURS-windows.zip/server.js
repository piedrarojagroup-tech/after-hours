'use strict';
const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const {createAI}=require('./ai-server');
function createServer({root=__dirname,ai=createAI(root)}={}){
 const entries=new Set(['index.html','episode.css','event-sim.js','episode-engine.js','episode-ui.js','service-worker.js','manifest.webmanifest','after-hours.html','after-hours.css','formation.css','live.css','formation.js','formation-ui.js','after-hours-world.js','after-hours.js','recruitment.js','live.js']);
 const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.webmanifest':'application/manifest+json; charset=utf-8','.png':'image/png'};
 return http.createServer(async(req,res)=>{
  const json=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));};
  if(!/^(127\.0\.0\.1|localhost):\d+$/.test(req.headers.host||''))return json(403,{error:'Local access only.'});
  let pathname;try{pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);}catch{return json(400,{error:'Invalid path.'});}
  if(pathname==='/api/status'&&req.method==='GET')return json(200,ai.status());
  if(pathname.startsWith('/api/')){
   if(req.method!=='POST')return json(405,{error:'POST required.'});
   if(req.headers.origin!=='http://'+req.headers.host)return json(403,{error:'Open this game on the local server to use AI.'});
   if(!/^application\/json(?:;|$)/i.test(req.headers['content-type']||''))return json(415,{error:'JSON required.'});
   try{let body='';const limit=pathname==='/api/episode-chat'?2000000:32000;for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>limit)return json(413,{error:'Message context is too large.'});}let input;try{input=JSON.parse(body);}catch{return json(400,{error:'Invalid JSON.'});}return json(200,await ai.run(pathname,input));}catch(err){return json(err.status||500,{error:err.status?err.message:'The request could not be completed.'});}
  }
  if(!['GET','HEAD'].includes(req.method))return json(405,{error:'Method not allowed.'});
  const relative=pathname==='/'?'index.html':pathname.slice(1);
  if(!entries.has(relative)&&!/^assets\/[a-zA-Z0-9_-]+\.png$/.test(relative)&&!/^generated\/[a-f0-9-]{36}\.png$/.test(relative))return json(404,{error:'Not found.'});
  const file=path.resolve(root,relative);
  try{const resolved=fs.realpathSync(file);if(!resolved.startsWith(fs.realpathSync(root)+path.sep))return json(403,{error:'Forbidden.'});const data=fs.readFileSync(file);res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});res.end(req.method==='HEAD'?undefined:data);}catch{return json(404,{error:'Not found.'});}
 });
}
if(require.main===module){const port=Number(process.env.PORT)||4173,server=createServer();server.on('error',err=>{console.error(err.code==='EADDRINUSE'?`Port ${port} is in use. Open http://127.0.0.1:${port} or change PORT.`:'Could not start local server.');process.exitCode=1;});server.listen(port,'127.0.0.1',()=>console.log(`AFTER HOURS: http://127.0.0.1:${port}\nPress Ctrl+C to stop.`));}
module.exports={createServer};
