@echo off
cd /d "%~dp0"
if not exist ".env.local" (
  copy /y ".env.example" ".env.local" >nul
  if errorlevel 1 (
    echo Could not create .env.local. Extract the ZIP to a folder you can edit.
    pause
    exit /b 1
  )
)
echo Choose a provider in AI_CHAT_PROVIDER and fill in that provider's API key.
echo See README.md for Gemini, MiniMax, OpenAI, and custom endpoints.
start "" notepad.exe "%CD%\.env.local"
