@echo off
cd /d "%~dp0"
where node >nul 2>nul
if %errorlevel%==0 (
  node launch-demo.cjs
) else (
  if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" (
    "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" launch-demo.cjs
  ) else (
    start "" "%~dp0index.html"
  )
)
if errorlevel 1 pause
